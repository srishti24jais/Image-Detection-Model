# Image-detection
##
 TECHNOLOGY USED:
 
1.tkinter for whole GUI

2.OpenCV for taking images and face recognition (cv2.face.LBPHFaceRecognizer_create())

3.CSV, Numpy, Pandas, datetime etc. for other purposes.


FEATURES:

Easy to use with interactive GUI support.

Password protection for new person registration.

Creates/Updates CSV file for deatils of students on registration.

Creates a new CSV file everyday for attendance and marks attendance with proper date and time.

Displays live attendance updates for the day on the main screen in tabular format with Id, name, date and time.

#### Installation

##### Install tk-tools

  pip install tk-tools

##### Install opencv-contrib-python

  pip install opencv-contrib-python

##### Install datetime

  pip install datetime

##### Install pytest-shutil

  pip install pytest-shutil

##### Install python-csv

  pip install python-csv

##### Install numpy

  pip install numpy

##### Install pillow

  pip install pillow 

##### Install pandas

  pip install pandas

##### Install times

  pip install times
  
  
  ##### video




https://user-images.githubusercontent.com/89032612/222944422-0ab04bb6-38e6-44d1-9983-3989ca4e7868.mp4

